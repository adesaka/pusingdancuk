
<html>
<head>
<link rel="shortcut icon" type="image/x-icon" href="http://www.fancyicons.com/free-icons/103/flags/png/48/indonesia_flag_48.png"><title>Starbucks Account Checker | MunafikC0de</title>
	<link href="https://brobin.github.io/hacker-bootstrap/css/hacker.css" rel="stylesheet">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/jquery-ui.js"></script>
	<script type="text/javascript">
		function selectText(containerid) {
		if (document.selection) {
			var range = document.body.createTextRange();
			range.moveToElementText(document.getElementById(containerid));
			range.select();
			} else if (window.getSelection()) {
				var range = document.createRange();
				range.selectNode(document.getElementById(containerid));
				window.getSelection().removeAllRanges();
				window.getSelection().addRange(range);
			}
		}
	</script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description" content="Starbucks Account Checker" />
    <meta name="author" content="Cornelius Alfredo" />
    <title>[+]Starbucks Account Checker[+]</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/blockui.js"></script>
</head>
<style media="screen">
.rainbow {

                            -webkit-background-clip: text;
                            -background-clip: text;
                            -webkit-text-fill-color: transparent;
                            -text-fill-color: transparent;
                            background-image: -webkit-gradient( linear, left top, right top, color-stop(0, #f22), color-stop(0.15, #f2f), color-stop(0.3, #66f), color-stop(0.45, #2ff), color-stop(0.6, #2f2),color-stop(0.75, #2f2), color-stop(0.9, #ff2), color-stop(1, #f22) );
                            background-image: gradient( linear, left top, right top, color-stop(0, #f22), color-stop(0.15, #f2f), color-stop(0.3, #66f), color-stop(0.45, #2ff), color-stop(0.6, #2f2),color-stop(0.75, #2f2), color-stop(0.9, #ff2), color-stop(1, #f22) );
                            }
                        .text-glow:hover, .text-glow:focus, .text-glow:active {
                           -webkit-stroke-width: 5.3px;
                           -webkit-stroke-color: #ccdddd;
                           -webkit-fill-color: #eeeeee;
                           text-shadow: 1px 0px 20px silver;
                           -webkit-transition: width 0.3s; /*Safari & Chrome*/
                           transition: width 0.3s;
                           -moz-transition: width 0.3s; /* Firefox 4 */
                           -o-transition: width 0.3s; /* Opera */
                           }
                       .text-glow a {
                           -webkit-transition: all 0.3s ease-in; /*Safari & Chrome*/
                           transition: all 0.3s ease-in;
                           -moz-transition: all 0.3s ease-in; /* Firefox 4 */
                           -o-transition: all 0.3s ease-in; /* Opera */
                           text-decoration:none;
                           color:white;
                       }
	body {
                                background:    #000000;
                                line-height: 1;
                                color: #bbb;
                                font-family: "CONSOLAS";
                                font-size: 12px;
                                background:#121214 url(img/suramadu.jpg) no-repeat center center fixed;
                                  -webkit-background-size: cover;
                                  -moz-background-size: cover;
                                  -o-background-size: cover;
                                  background-size: cover;

                        }
	.form-control[disabled],.form-control[readonly],fieldset[disabled] .form-control {
		background-color: rgba(8, 8, 8, 0.90);
		opacity:1
	}
	.panel {
		background-color: rgba(8, 8, 8, 0.64);
		color: white;
	}
	.form-control {
		background-color: rgba(2, 2, 2, 0.49);
		color: white;
	}
	.form-control::-moz-placeholder {
		color: white;
		opacity:1;
	}
	.form-control:-ms-input-placeholder {
		color: white;
	}
	.form-control::-webkit-input-placeholder {
		color: white;
	}
	.btn-warning,
	.btn-info {
		background-color: rgba(255, 255, 255, 0.82);
	}
	.btn-warning:hover,
	.btn-warning:focus,
	.btn-info:hover,
	.btn-info:focus {
		background-color: rgba(255, 255, 255, 0.50);
	}

	.btn-danger:hover,
	.btn-danger:focus,
	.btn-danger,
	.btn-success:hover,
	.btn-success:focus,
	.btn-success {
		border-color: 0px solid white;
		color: white;
	}
.form-control[disabled], .form-control[readonly], fieldset[disabled] {
    background-color: rgba(255, 255, 255, 0.27);
    opacity: 1;
    color: white;
}
.form-control:focus {
    border-color: white;
    outline: 0;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(0, 255, 0, 0.6);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px white;
}
                        textarea, input, select {
                                border:0;
                                BORDER-COLLAPSE:collapse;
                                border:double 2px #696969;
                                color:#fff;
                                background:#000000;
                                margin:0;
                                padding:2px 4px;
                                font-family: Lucida Console,Tahoma;
                                font-size:12px;
                                box-shadow: 0 0 15px gray;
                                -webkit-box-shadow: 0 0 15px gray;
                                -moz-box-shadow: 0 0 15px blue;
                        }
                        .title{
                                color: #eee;
                                background:    black;
                                text-align:    center;
                                font-size:    120%;
                        }
                        .button{
                                color:#eee;
                        }
                        .tool{
                                color:lime;
                        }
                        header {
                                font-family: Lucida Console;
                                font-size: 12px;
                                text-align: center;
                                padding-top: 10px;
                                color: #626262;
                        }
                        /* Gradient 1 */
                        .ta10 {
                            background: background:rgba(0,225,0,00);
                            background-color: black;
                            background-repeat:no-repeat;
                            background-size: 52% 100%;
                            background-position: center;
                            border:2px double #696969;
                            padding:3px;
                            margin-right:4px;
                            margin-bottom:8px;
                            font-family: Lucida Console,Tahoma;
                            font-size:12px;
                            box-shadow: 0 0 5px white;
                           -webkit-box-shadow: 0 0 5px white;
                           -moz-box-shadow: 0 0 5px white;
                           border: solid 0px transparent; // or border: none;
                        }                       
        </style>
<body>
<header>
<div>
<a href="http://fb.me/maybe.edo">
<font color="red">kimakproject</a>@tamvaners.club</font><br><font size="2" color="gold">[New Checker]</FONT>
<hr />
<font size="5" color="white" style="text-shadow: #ddd 0 0 15px;" class="panel"><b>~|Starbucks Account Checker|~</b></font>
<hr />
<div align="center">
</header>
	<div class="container">

		<div class="row">
			<div class="col-md-1 col-xs-1 col-lg-1"></div>
			<div class="col-md-11 col-lg-11 col-xs-11" style="margin-top: 2%;">
				<div class="panel">
					<div class="panel-heading">
					   Thanks To : ./OchillBintangS.
<span class="pull-right">
							( <button type="button" class="btn btn-xs btn-success"><a href="https://facebook.com/ngok89/" target="_blank"><font color="black">Contact Here</font></a></button> )</span>
						</span>
					</div>
					<div class="panel-body">
						<textarea name="mailpass" id="mailpass" placeholder="root@background-clip.net|keykimak" class="form-control" rows="7"></textarea><br>
						<p align="center">
                            Delim: <input name="delim" id="delim" style="text-align: center;display:inline;width: 40px;margin-right: 8px;padding: 4px;" value="|" type="text" class="form-control">
<input type="hidden" name="token" id="token" value="dfbwdfiuwhdfuiwdiufhwdhfwdhfudwhfwh"/>
							<button type="button" class="btn btn-success" id="submit">Check</button>
							<button type="button" class="btn btn-danger" id="stop">Stop</button>
							<img id="loading"><br>
						</p>
                        <p align="right">
                            <span id="checkStatus" style="color:limegreen"></span>
                        </p>
<hr><br>
    <div class="row">
      <div class="col-md-1 col-xs-1 col-lg-1"></div>
      <div class="col-md-11 col-xs-11 col-lg-11">
        <div id="result" style="display: none;">
          <div class="row">
            <div class="col-md-12 col-xs-12 col-lg-12">
              <div class="panel">
                <div class="panel-heading">
                  LIVE &nbsp;
                  <span class="label label-success" id="acc_live_count">0</span>
                  <span class="pull-right">
                    <button onclick="selectText('acc_live')" type="button" class="btn btn-xs btn-warning"><i class="fa fa-copy"></i> Copy All</button>
                    <button type="button" id="live_btn-hide" class="btn btn-xs btn-warning"><i class="fa fa-minus"></i> Hide</button>
                  </span>
                </div>
                <div id="body_live" class="panel-body">
                  <div id="acc_live"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 col-xs-12 col-lg-12">
              <div class="panel">
                <div class="panel-heading">
                  DIE &nbsp;
                  <span class="label label-danger" id="acc_die_count">0</span>
                  <span class="pull-right">
                    <button type="button" class="btn btn-xs btn-warning" id="die_hide"><i class="fa fa-minus"></i> Hide</button>
                  </span>
                  <script type="text/javascript">
                    $(document).ready(function() {
                      $('#live_btn-hide').click(function() {
                        $('#body_live').toggle(1000);
                      });
                      $('#die_hide').click(function() {
                        $('#body_hide_die').toggle(1000);
                      });
                      $('#wrong-btn-hide').click(function() {
                        $('#wrong-body-hide').toggle(1000);
                      });
                    });
                  </script>
                </div>
                <div id="body_hide_die" class="panel-body">
                  <div id="acc_die"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 col-xs-12 col-lg-12">
              <div class="panel">
                <div class="panel-heading">
                  WRONG &nbsp;
                  <span id="wrong_count" class="label label-warning">0</span>
                  <span class="pull-right">
                    <button type="button" id="wrong-btn-hide" class="btn btn-xs btn-warning"><i class="fa fa-minus"></i> Hide</button>
                  </span>
                </div>
                <div id="wrong-body-hide" class="panel-body">
                  <div id="wrong"></div>
                </div>
              </div>
            </div>
          </div>
      <div class="col-md-1 col-xs-1 col-lg-1"></div>
    </div>
  </div>

<script type="text/javascript" src="js/munafikcode.js"></script>
</body>
</html>